
from flask import Flask, render_template, request, send_file
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from PyPDF2 import PdfReader, PdfWriter
import io
import base64

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit():
    data = request.form

    # Handle signatures
    engineer_sig_data = data['engineer_signature'].split(',')[1]
    customer_sig_data = data['customer_signature'].split(',')[1]

    engineer_sig = base64.b64decode(engineer_sig_data)
    customer_sig = base64.b64decode(customer_sig_data)

    # Create a new PDF overlay
    packet = io.BytesIO()
    c = canvas.Canvas(packet, pagesize=A4)

    # Example coordinates (you can adjust these as needed)
    c.drawString(100, 800, f"Customer: {data['customer']}")
    c.drawString(100, 780, f"Job No: {data['job_no']}")
    c.drawString(100, 760, f"Job Type: {data['job_type']}")
    c.drawString(100, 740, f"Customer Ref: {data['customer_ref']}")
    c.drawString(100, 720, f"Site Address: {data['site_address']}")
    c.drawString(100, 700, f"Travel Start: {data['travel_start']} | Arrival: {data['site_arrival']}")
    c.drawString(100, 680, f"Depart: {data['site_depart']} | Finish: {data['travel_finish']}")
    c.drawString(100, 660, f"Date: {data['date']}")
    c.drawString(100, 640, f"Make/Model: {data['make']} / {data['model']}")
    c.drawString(100, 620, f"Description: {data['description']}")
    c.drawString(100, 600, f"Serial: {data['serial']} | Location: {data['location']}")
    c.drawString(100, 580, f"Work Description: {data['work_description']}")
    c.drawString(100, 560, f"Engineer Report: {data['engineer_report']}")
    c.drawString(100, 540, f"Recommendations: {data['recommendations']}")
    c.drawString(100, 520, f"Engineer: {data['engineer_name']}")

    c.drawImage(io.BytesIO(engineer_sig), 400, 100, width=100, height=50)
    c.drawImage(io.BytesIO(customer_sig), 100, 100, width=100, height=50)

    c.save()
    packet.seek(0)

    # Merge overlay with original PDF
    existing_pdf = PdfReader("Blank Service Sheet4.pdf")
    output = PdfWriter()
    new_pdf = PdfReader(packet)

    page = existing_pdf.pages[0]
    page.merge_page(new_pdf.pages[0])
    output.add_page(page)

    output_stream = io.BytesIO()
    output.write(output_stream)
    output_stream.seek(0)

    return send_file(output_stream, as_attachment=True, download_name="Completed_Service_Sheet.pdf", mimetype='application/pdf')

if __name__ == '__main__':
    app.run(debug=True)
